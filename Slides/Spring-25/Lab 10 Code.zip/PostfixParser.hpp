//
//  PostfixParser.hpp
//  Lab 10
//
//  Created by Kyle Parker on 3/24/25.
//

#ifndef PostfixParser_hpp
#define PostfixParser_hpp

#include <vector>
#include <string>
#include <memory>
#include <type_traits> // used for std::is_arithmetic

#include "Token.hpp"

using std::vector;
using std::string;
using std::shared_ptr; // used for automatic deallocation
using std::make_shared; // used for automatic deallocation

namespace MyLib {

template <typename T>
class PostfixParser {
    static_assert(std::is_arithmetic<T>::value, "T must be an arithmetic type"); // Makes types such as std::string invalid and will not compile.
    
public:
    PostfixParser(const string& str) : _input(str) {}
    
    // This will return a vector of shared pointers to token of type T.
    // A vector is a container which is can be thought of as similar to lists.
    // A shared token is a "smart pointer" which will be removed from memory once it is unused
    vector<shared_ptr<MyLib::Token<T>>> parse(); // MyLib:: not required as we are in MyLib namespace
    
private:
    string _input;
    vector<shared_ptr<MyLib::Token<T>>> _tokens; // MyLib:: not required as we are in MyLib namespace
    
    void _parseInput();
};
}

#include "PostfixParser.ipp"

#endif /* PostfixParser_hpp */
