//
//  main.cpp
//  Lab 10
//
//  Created by Kyle Parker on 3/24/25.
//

#include <iostream>

#include "PostfixEvaluator.hpp"

int main(int argc, const char * argv[]) {
    // insert code here...
    
    /// Call create an evaluator that will process the given equation. Allows up to 20 items in the stack
    MyLib::PostfixEvaluator<int> evaluator("5 23 * =", 20);
    
    // Evaluate the expression passed in.
    int result = evaluator.evaluate();
    
    
    // Print the result
    std::cout << "Result = " << result << std::endl;
    
    return 0;
}
