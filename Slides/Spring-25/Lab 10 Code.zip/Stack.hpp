#ifndef STACK_HPP
#define STACK_HPP

// This file contains a stack class template. The underlying data structure for the 
// stack is an array allocated from the heap.

#include <string>

using std::cout;
using std::cin;
using std::endl;
using std::string;

namespace MyLib {

template <class T>
class Stack
{
public:
    Stack(int newSize = 0, int maxSize = 0);
    ~Stack();

    bool push(const T& newItem);
    bool pop(T& poppedItem);
    bool peek(T& item);

    bool isEmpty();

private:
    int _size; // represents the current number of items in the stack
    const int _max; // must not exceed the max size of our allocated array
    T* _top; // will point to contigous memory on the heap (an array)
};

}

#include "Stack.ipp"

#endif /* STACK_HPP */
