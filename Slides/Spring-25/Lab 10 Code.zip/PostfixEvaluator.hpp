//
//  PostfixEvaluator.hpp
//  Lab 10
//
//  Created by Kyle Parker on 3/24/25.
//

#ifndef PostfixEvaluator_hpp
#define PostfixEvaluator_hpp

#include "PostfixEvaluationException.h"
#include "PostfixParser.hpp"
#include "Stack.hpp"

// Create/use the MyLib namespace
namespace MyLib {

// Create a postfixEvaulator class using templates.
template <typename T>
class PostfixEvaluator {
    // Ensure type T is an arithmetic value (int, double, float, long, etc.)
    static_assert(std::is_arithmetic<T>::value, "T must be an arithmetic type"); // Makes types such as std::string invalid and will not compile.
public:
    // Constructor
    PostfixEvaluator(const string& expression, const int& maxExpLen) :
    // Using an initalizer list, provide _expression and _stack with values.
        _expression(expression),
    // ** CHANGE FROM LAB ** //
    // I had a typo here where I only passed in the first agument. However, I
    // wanted to pass in maxExpLen as the second argument and 0 as the first.
    // This means we start at index 0 and we have upto maxExpLen items to push onto the stack.
        _stack(0, maxExpLen) {
            // Create the parser and set _tokens equal to the parsed tokens.
            PostfixParser<T> parser(expression);
            _tokens = parser.parse();
        }
    
    // Public interface for evaluate
    T evaluate();
    
private:
    // A vector of shared_ptr types, which point to Token<T> types.
    // A shared_ptr is considered a "smart pointer". When the pointer
    // goes out of scope, it will be destroyed automatically.
    vector<shared_ptr<Token<T>>> _tokens;
    string _expression;
    Stack<T> _stack;
    
    // Private back-end implementation of evaluate
    T _evaluate();
};

}

#include "PostfixEvaluator.ipp"

#endif /* PostfixEvaluator_hpp */
