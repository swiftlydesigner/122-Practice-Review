#pragma once

#include "Stack.hpp"

template <class T>
class TestStack
{
public:
	TestStack();
	~TestStack();
	void Test(T& item1, T& item2);
    
    void TestPushFullStack();

private:
	Stack<T> theStack;
};


// MARK: - Implement TestStack

template <class T>
TestStack<T>::TestStack() : theStack(0) // this is initializing the newSize of the stack object to 0
{

}

template <class T>
TestStack<T>::~TestStack()
{

}

template <class T>
void TestStack<T>::Test(T& item1, T& item2)
{
	theStack.push(item1);
	theStack.peek(item2);
	cout << "peek: " << item2 << endl;
}


template <typename T>
void TestPushFullStack() {
    theStack = Stack<T>(0, 1);
    
    bool success = theStack.push(T());
    
    if (!success) {
        throw new std::runtime_exception("Expected the first push to succeed, but it failed.");
    }
    
    success = theStack.push(T());
    
    if (success) {
        throw new std::runtime_exception("Expected the second push to fail, but it succeeded.");
    }
}
