//
//  PostfixEvaluationException.h
//  Lab 10
//
//  Created by main on 3/29/25.
//

#ifndef PostfixEvaluationException_h
#define PostfixEvaluationException_h

#include <exception>

/// Exception thrown when something goes wrong during evaluation
class PostfixEvaluationException final : public std::runtime_error {
public:
    // Marked as explicit to ensure there are no implicit conversions for the constructor (I am following the base class' declaration)
    /// Create an exception
    /// @param what Description of the exception
    //                                                             Calling base class constructor
    explicit PostfixEvaluationException(const std::string& what) : std::runtime_error(what) {}
};

#endif /* PostfixEvaluationException_h */
