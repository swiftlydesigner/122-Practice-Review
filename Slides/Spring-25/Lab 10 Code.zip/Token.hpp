//
//  Token.hpp
//  Lab 10
//
//  Created by Kyle Parker on 3/24/25.
//

#ifndef Token_hpp
#define Token_hpp

// Most conent has changed below. Please take note of everything we do as this is
// the current unit.
//
// Virtual means that this function can be invoked on polymorphic types without
// needing to know the concrete type.
//
// Functions set to zero (= 0) indicate that they are "pure virtual" functions.
// This means there is no default implementation, and concrete types must provide
// their own implementation. Classes or structures with one or more "pure virtual"
// functions are called abstract. In the context of inheritance, abstraction is not
// the same as procedural abstraction. Instead, abstraction refers to a class from
// which other classes can inherit and implement their own versions, creating what
// is known as a concrete class. Abstract classes cannot be instantiated.
//
// When inheriting from a template class, it is not necessary for all derived classes
// to be templates as well. While it happens to be the case in this program, you can
// specialize the template when inheriting, as shown below:
//
// class MyClass : public MyTemplate<int> {};


namespace MyLib {

// Base which Operand and Operator inherit from.
template <typename T>
struct Token {
    // Mark the destructor as virtual. This allows the destructor to be called properly when using polymorphism.
    virtual ~Token() {}
    
    // Make the function `evaluate` return type `T`. Marked as `virtual` and is pure-virtual.
    virtual T evaluate() = 0;
};

// Create an operand which inherits publicly from Token. Marked as final.
// Final indicates the class cannot be inherited from another class.
template <typename T>
struct Operand final : public Token<T> {
    virtual ~Operand() {}
    
    Operand(const T& newVal) : value(newVal) {}
    
    // When we evauluate an operand, the product is its value.
    virtual T evaluate() { return value; }
    
private:
    const T value;
};

// Operator is a slightly more complex.
// We need to inherit from Token and have two versions of evaluate.
// Only the pure virtual evaluate with two parameters will be important for derived classes.
template <typename T>
struct Operator : public Token<T> {
    virtual ~Operator() {}
    Operator() {}
    
    // Define a function only visible in Operator and derived classes of Operator.
    // Pure virtual as to force derived classes to implement it.
    virtual T evaluate(const T& first, const T& second) = 0;
    
    virtual T evaluate() {
        return evaluate(T(), T());
    }
};

// For add, we simply define the behvaior of evaulate to return the sum of the first and second operands.
template <typename T>
struct Add : public Operator<T> {
    T evaluate(const T& first, const T& second) {
        return first + second;
    }
};

// For sub, we simply define the behvaior of evaulate to return the difference of the first and second operands.
template <typename T>
struct Sub : public Operator<T> {
    T evaluate(const T& first, const T& second) {
        return first - second;
    }
};

// For div, we simply define the behvaior of evaulate to return the quotient of the first and second operands.
template <typename T>
struct Div : public Operator<T> {
    T evaluate(const T& first, const T& second) {
        return first / second;
    }
};

// For mul, we simply define the behavior of evaluate to return the product of the first and second operands.
template <typename T>
struct Mul : public Operator<T> {
    T evaluate(const T& first, const T& second) {
        return first * second;
    }
};

}

#endif /* Token_hpp */
