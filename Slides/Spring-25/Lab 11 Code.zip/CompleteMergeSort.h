//
// Created by Kyle Parker on 4/1/25.
//

#ifndef COMPLETEMERGESORT_H
#define COMPLETEMERGESORT_H

#include <vector>

using std::vector;

// Why are function names in UpperCamelCase?
//    UpperCamelCase is tradition for static functions.

// Without the demo function, this class should be a template based on my implementation.
// I wanted to highlight the fact member functions can be template without requiring the
// class to be template.
//
class CompleteMergeSort {
public:
    template <typename T>
    static void MergeSort(vector<T>& v);

    static void Demo();

private:
    template <typename T>
    static void Merge(vector<T>& v, const int& left, const int& mid, const int& right);

    template <typename T>
    static void MergeSort(vector<T> &v, const int &left, const int &right);

};

#include "CompleteMergeSort.ipp"

#endif //COMPLETEMERGESORT_H
