//
//  BST.hpp
//  Lab 11 [Spr 25]
//
//  Created by Kyle Parker on 3/31/25.
//

#ifndef BST_hpp
#define BST_hpp

#include "Node.hpp"

template <typename T>
class BST {
    Node<T>* _root;

    void destroyTree(Node<T>*& root);

    bool insert(Node<T>*& root, const T& data);

    bool remove(Node<T>*& root, const T& target);

public:
    BST() : _root(nullptr) {
        // Nothing to do
    }

    BST(const BST& other) = delete; // Disable the copy constructor

    ~BST() {
        destroyTree(_root);
    }

    BST& operator=(const BST& rhs) = delete; // Disable = operator


    bool insert(T data) {
        return insert(_root, data);
    }

    bool remove(T target) {
        return remove(_root, target);
    }
};

#include "BST.ipp"

#endif /* BST_hpp */
