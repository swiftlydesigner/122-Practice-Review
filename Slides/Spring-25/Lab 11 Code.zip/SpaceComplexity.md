# Big-O time and space complexity of functions in CompleteMergeSort.h

## What the Big-O *time* complexity of `void CompleteMergeSort::MergeSort(vector<T> &v)`?
### Answer: $O(n \log n)$
- We call `MergeSort` which has two factors (explained below), causing $O(n \log n)$ time.

## What the Big-O *space* complexity of `void CompleteMergeSort::MergeSort(vector<T> &v)`?
### Answer: $O(n)$
- Although there is no auxiliary space used, the space complexity of callees is $O(n)$ which affects this function.

## What the Big-O *time* complexity of `inline void CompleteMergeSort::Demo()`?
### Answer: $O(n)$
- Two `for` loops both iterate over the same vector, of assumed size n.
- $O(n + n) = O(2n) = O(n)$

## What the Big-O *space* complexity of `inline void CompleteMergeSort::Demo()`?
### Answer: $O(n)$
- As `vector::push_back` is used, the space complexity is $O(n)$.
    - Due to `std::vector`'s nature, the space is dependent on how many `push_back` calls there are.

## What the Big-O *time* complexity of `void CompleteMergeSort::Merge(vector<T> &v, const int& left, const int& mid, const int& right)`?
### Answer: $O(n)$
- Iterates over the vector at most $O(n)$ times, the length of the input.

## What the Big-O *space* complexity of `void CompleteMergeSort::Merge(vector<T> &v, const int& left, const int& mid, const int& right)`?
### Answer: $O(n)$
- Stores up to the size of the vector, thus providing $O(n)$ time.

## What the Big-O *time* complexity of `void CompleteMergeSort::Merge(vector<T> &v, const int& left, const int& mid, const int& right)`?
### Answer: $O(n)$
- Iterates over the vector at most $O(n)$ times, the length of the input. We know `leftSize` and `rightSize` will be at most 1/2 the size of `v` - the input size.
- $O\left(\frac{n}{2}\right) + O\left(\frac{n}{2}\right) = O(n)$

## What the Big-O *space* complexity of `void CompleteMergeSort::Merge(vector<T> &v, const int& left, const int& mid, const int& right)`?
### Answer: $O(n)$
- We need to store the whole vector in our temp vectors (`leftVector` and `rightVector`), making the space input-size dependent.

## What the Big-O *time* complexity of `void CompleteMergeSort::MergeSort(vector<T> &v, const int& left, const int& right)`?
### Answer: $O(n \log n)$
- Recursion will be called $O(\log n)$ times. But, we call `Merge` which has time complexity of $O(n)$. Therefore, we multiply as seen below.
- $O(\log(n) * n) = O(n \log n)$

## What the Big-O *space* complexity of `void CompleteMergeSort::MergeSort(vector<T> &v, const int& left, const int& right)`?
### Answer: $O(n)$
- We call `Merge` which uses up to $O(n)$ auxiliary space.
