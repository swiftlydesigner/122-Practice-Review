//
//  Node.hpp
//  Lab 11 [Spr 25]
//
//  Created by Kyle Parker on 3/31/25.
//

#ifndef Node_h
#define Node_h

// Note: A struct is used here for simplicity.
// It is considered good practice to employ encapsulation, which is
// usually implemented via a class. This example serves to introduce
// the concept of struct types in C++.
//
// Important Note: Exams will employ classes that incorporate encapsulation.
// Therefore, familiarity with appropriate getters and setters is necessary.

template <typename T>
struct Node {
    T data;

    Node* left;
    Node* right;

    Node(const T& newData) {
        data = newData;
        left = right = nullptr;
    }
};


#endif /* Node_h */
