﻿//
//  main.cpp
//  Lab 11 [Spr 25]
//
//  Created by Kyle Parker on 3/31/25.
//

// Lab11CMake/
//   Main.cpp: Program entry
//   BST.ipp: Definition of BST class
//   BST.hpp: Declaration of BST class
//   Node.hpp: Definition of Node class
//   CMakeLists.txt: Defines the files to build.

#include "BST.hpp"
#include "CompleteMergeSort.h"

// TODO: Implement merge sort

int main(int argc, const char* argv[]) {
    // insert code here...
    BST<int> bst;

    bst.insert(10);

    CompleteMergeSort::Demo();

    return 0;
}
