//
//  Queue.cpp
//  Lab 8 '25
//
//  Created by Kyle Parker on 3/3/25.
//

#include <iostream>

#include "Queue.hpp"

using std::cout;
using std::endl;

// MARK: - Private

// MARK: Private Member Functions

/// Recursive print from _head to _tail. This is called from a public interface, of which _head is initially passed in.
/// \Param current - The current node to print
void Queue::_print(Node * current) {
    if (current) {
        cout << current << endl;
        this->_print(current->next());
    }
}

/// Destroy the entire queue
void Queue::_destroyQueue() {
    while (!this->isEmpty()) {
        this->dequeue();
    }
}

// MARK: - Public

// MARK: Lifecycle

// The lifecycle of the program consists of:
// 1) Creation (i.e., `Queue q;`)
// 2) Initalization (Constructor)
// 3) Usage (i.e., `q.isEmpty()`)
// 4) Destruction (Destructor)

// As such, we will have 2 and 4 declared within the Lifecycle comment.

/// Destroy the entire queue
Queue::~Queue() {
    this->_destroyQueue();
}

// MARK: Public Member Functions

/// Check if the queue is empty. True if empty, false otherwise.
/// \returns If the queue is empty or not.
bool Queue::isEmpty() {
    // Here, we simply check if _head equals _tail and we ensure the head is null
    return this->_head == this->_tail &&
        this->_head == nullptr;
    
    // This checks if head is null and tail is null
    return !this->_head && !this->_tail;
    
    // Important: !! will treat any value as 1 or 0. If the value is 0, then 0 is returned; o.w., 1 is returned.
    
    // This checks the head and tail are equal and the head is nullptr.
    // Breaking it down:
    // 1) !!this->_head will be 1 when _head has a value and 0 when null
    // 2) !!this->_tail will be 1 when _tail has a value and 0 when null
    // 3) [1] XOR [2] will be 1 when they are not equal and 0 when they are equal
    // 4) NOT([3]) will be true when head and tail are equal, and false otherwise
    // 5) [4] BITWISE AND !this->_head ensures head and tail are equal, then verifies head is nullptr
    return !(!!this->_head ^ !!this->_tail) & !this->_head;
    
    
    // Possibly the fastest evaluation
    // This checks if head and tail are nullptr
    // 1) !!this->_head will be 1 when _head is non-null, 0 o.w.
    // 2) !!this->_tail will be 1 when _tail is non-null, 0 o.w.
    // 3) [1] | [2] will be 1 when _head and/or _tail is non-null, 0 o.w.
    // 4) NOT([3]) will be 1 when _head and _tail are null, 0 o.w.
    return !(!!this->_head | !!this->_tail);
    
    // Why did I write so many different approaches?
    // 1) This shows there are many ways to the same objective
    // 2) Allows you to understand readability
    // 3) Shows that there may be more efficent algorithms with the handoff of readability
    
    // I encourage all of you to come up with a solution that is not a standard approach,
    // but something that requires you to think. Don't always think like the crowd.
    // Stand out and try another approach that others will criticize. It may not be a good
    // approach, and you may not want to do this in an interview, but thinking outside the
    // box will help you understand the content.
}

/// Enqueue some data into the queue.
/// \Param data - The new string to insert
/// \Returns Success indicator of memory allocation
bool Queue::enqueue(const string& data) {
    
    Node * newNode = new Node(data);
    
    if (newNode != nullptr) {
        
        if (this->isEmpty()) {
            this->_head = this->_tail = newNode;
        } else {
            this->_tail->setNext(newNode);
            this->_tail = newNode;
        }
        
    }
    
    return newNode != nullptr;
}

/// Dequeue the data at the head.
/// \Returns The data at the head, or nullopt if the queue is empty.
/// \Warning If the queue is empty, std::nullopt will be the returned value.
optional<string> Queue::dequeue() {
     // Provide the nullopt default value (aka the queue is empty)
    optional<string> poppedData = std::nullopt;
    Node * pTemp;
    
    if (this->_head != nullptr) {
        pTemp = this->_head;
        
        poppedData = this->_head->data();
        this->_head = this->_head->next();
        
        delete pTemp;
        
        // Update tail to nullptr
        if (this->_head == nullptr) {
            this->_tail = this->_head;
        }
    }
    
    return poppedData;
}

/// Public interface for the print function.
void Queue::print() {
    this->_print(this->_head);
}
