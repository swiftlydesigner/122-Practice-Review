//
//  QueueTestSuiteEx.mm
//  QueueTestSuiteEx
//
//  Created by Kyle Parker on 3/3/25.
//

#import <XCTest/XCTest.h>

#import "Queue.hpp"

@interface QueueTestSuiteEx : XCTestCase

@property (nonatomic) Queue *queue;
@property (nonatomic) string *testData1;
@property (nonatomic) string *testData2;

@end

@implementation QueueTestSuiteEx

- (void)setUp {
    // Put setup code here. This method is called before the invocation of each test method in the class.
    _queue = new Queue();
    _testData1 = new string("Test Data 1");
    _testData2 = new string("Test Data 2");
}

- (void)tearDown {
    // Put teardown code here. This method is called after the invocation of each test method in the class.
    delete _queue;
    _queue = nullptr;
    
    delete _testData1;
    _testData1 = nullptr;
    
    delete _testData2;
    _testData2 = nullptr;
}

- (void)testEnqueueEmpty {
    // Enqueue some data
    XCTAssertTrue(_queue->enqueue("Test Data"), @"Enqueue failed");
    
    // Expect non-empty
    XCTAssertFalse(_queue->isEmpty(), @"Expected non-empty queue");
    
    // Expect head & tail are same
    XCTAssertEqual(_queue->head(), _queue->tail(), @"Expected head and tail are the same");
    
    // Expect head is non-null
    XCTAssertNotEqual(_queue->head(), nullptr, @"Expected head is not nullptr");
    
    // Expect head->next is null
    XCTAssertEqual(_queue->head()->next(), nullptr, @"Expected head's next is nullptr");
}

- (void)testEnqueueNonEmpty {
    XCTAssertTrue(_queue->enqueue(*_testData1), @"Enqueue 1 failed");
    XCTAssertTrue(_queue->enqueue(*_testData2), @"Enqueue 2 failed"); // UUT
    
    XCTAssertFalse(_queue->isEmpty(), @"Expected non-empty queue");
    
    XCTAssertNotEqual(_queue->head(), _queue->tail(), @"Expected head and front are different");
    
    XCTAssertNotEqual(_queue->head(), nullptr, @"Expected head is not nullptr");
    
    XCTAssertEqual(_queue->head()->next(), _queue->tail(), @"Expected head's next is tail");
    
    XCTAssertEqual(_queue->tail()->next(), nullptr, @"Expected tail's next is nullptr");
}

- (void)testDequeueTwoEles {
    XCTAssertTrue(_queue->enqueue(*_testData1), @"Enqueue 1 failed");
    XCTAssertTrue(_queue->enqueue(*_testData2), @"Enqueue 2 failed");
    
    // We no longer care about enqueue succeded, other tests are for that.
    
    optional<string> result = _queue->dequeue();
    XCTAssertTrue(result.has_value(), @"Dequeue should have succeeded");
    XCTAssertEqual(result.value(), *_testData1, @"Data should be `Test Data`");
    
    // isEmpty has been tested
    XCTAssertFalse(_queue->isEmpty(), @"Queue should not be empty!");
    
    XCTAssertEqual(_queue->head(), _queue->tail(), @"Queue head should be tail");
}

- (void)testDequeueOneEle {
    XCTAssertTrue(_queue->enqueue(*_testData1), @"Enqueue 1 failed");
    
    // We no longer care about enqueue succeded, other tests are for that.
    
    optional<string> result = _queue->dequeue();
    XCTAssertTrue(result.has_value(), @"Dequeue should have succeeded");
    XCTAssertEqual(result.value(), *_testData1, @"Data should be `Test Data`");
    
    // isEmpty has been tested
    XCTAssertTrue(_queue->isEmpty(), @"Queue should be empty!");
}

// Note: You only need this test with defensive programming
- (void)testDequeueEmpty {
    optional<string> result = _queue->dequeue();
    XCTAssertFalse(result.has_value(), @"Dequeue should have failed");
}

- (void)testIsEmpty {
    // Test isEmpty functionality
    XCTAssertTrue(_queue->isEmpty(), @"Queue should be empty initially");
    
    _queue->enqueue(*_testData1);
    XCTAssertFalse(_queue->isEmpty(), @"Queue should not be empty after enqueue");
    
    _queue->dequeue();
    XCTAssertTrue(_queue->isEmpty(), @"Queue should be empty after dequeue");
}

- (void)testPerformanceExample {
    // This is an example of a performance test case.
    [self measureBlock:^{
        // Put the code you want to measure the time of here.
    }];
}

@end
