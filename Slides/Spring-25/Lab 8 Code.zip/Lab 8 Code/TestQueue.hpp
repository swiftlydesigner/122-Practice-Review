//
//  TestQueue.hpp
//  Lab 8 '25
//
//  Created by main on 3/4/25.
//

#ifndef TestQueue_hpp
#define TestQueue_hpp

#include "Queue.hpp" // uut

class TestQueue {
    Queue * queue;
    const string s1;
    const string s2;
    
    void setup() {
        queue = new Queue();
    }
    
    void tearDown() {
        delete queue;
    }
    
public:
    TestQueue() : s1("First"), s2("Second") {}
    
    void testEnqueueEmpty();
    
};

#endif /* TestQueue_hpp */
