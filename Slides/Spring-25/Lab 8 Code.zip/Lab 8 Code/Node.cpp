//
//  Node.cpp
//  Lab 8 '25
//
//  Created by Kyle Parker on 3/3/25.
//

#include "Node.hpp"

// Nothing special here

Node* Node::next() {
   return _next;
}

void Node::setNext(Node *newNext){
   _next = newNext;
}

string Node::data() {
    return _data;
}
