//
//  TestQueue.cpp
//  Lab 8 '25
//
//  Created by main on 3/4/25.
//

#include <iostream>
#include "TestQueue.hpp"

using std::cout;
using std::cerr;
using std::endl;

// This tests enqueue on an initally empty queue.
void TestQueue::testEnqueueEmpty() {
    setup();
    // Enqueue some data
    bool success = queue->enqueue(s1);
    
    // Ensures the enqueue was successful. Even if true is returned, we need to check further.
    if (!success) {
        cerr << "[" << __FUNCTION__ << "]" << " Enqueue failed." << endl;
    }
    
    // Ensure the queue is not empty
    if (queue->isEmpty()) {
        cerr << "[" << __FUNCTION__ << "]" << " Queue is empty." << endl;
    }
    
    // Verify the head and tail are the same
    if (queue->head() != queue->tail()) {
        cerr << "[" << __FUNCTION__ << "]" << " Queue's head and tail are not the same." << endl;
    }
    
    // Ensure the head is non-null
    if (queue->head() == nullptr) {
        cerr << "[" << __FUNCTION__ << "]" << " Expected head is not nullptr." << endl;
    }
    
    // Ensure the head's next is nullptr.
    if (queue->head()->next() != nullptr) {
        cerr << "[" << __FUNCTION__ << "]" << " Expected head's next is nullptr" << endl;
    }
    
    tearDown();
}
