//
//  main.cpp
//  Lab 8 '25
//
//  Created by Kyle Parker on 3/3/25.
//

#include "TestQueue.hpp"

// 19 min for Queue + Node
// 25 min for Queue tests
// Total time ~45 min
// 
// I have been programming in C and C++ for roughly 5 years and Swift for a little over 10 years.
// As such, my coding time will be shorter than yours. If you cannot code the whole Queue and Node
// class in under 20 minutes, keep trying to write code faster with fewer mistakes. It may feel
// redundant, but you will learn the data structure much better by writing it over and over again.
// In practice, you are likely to use the STL. You still need to understand how they operate, which
// is why this class exists and AI usage is limited. If any of you have trouble with these, keep
// trying until you succeed! Hard work will pay off in the future!

int main(int argc, const char * argv[]) {
    // insert code here...
    
    // Please view the QueueTestSuiteEx.mm file. The .mm file extension tells us it is an
    // Objective-C++ file. As such, the format of our class is a little different from what you may
    // be familiar with. While I strongly encourage you to be able to read this, it is not required.
    // It is always good to be able to read many different languages
    // (and even better to write in others).
    
    // Another important concept in the .mm file is the assert statements. For example, when you see
    // XCTAssertTrue, you should be able to look at this and know that we will pass in a condition
    // which we expect to be true. That is, XCTAssertTrue(true, @"Something went really wrong") should
    // always pass since we are passing in true. However, a statement like
    // XCTAssertTrue(false, @"All is good, false is never true!") should always fail since false ≠ true.
    
    // A similar example is XCTAssertEqual(o1, o2, @"o1 should have been o2"). When you see XCTAssertEqual,
    // you should think, "I need to pass in two arguments." If you can start thinking in this way and read
    // the code easily, that is great.
    
    // Using test suites will be a little odd at first, but once you understand the flow, it will be easier.
    // However, figuring out what we are testing and what attributes should be tested may not always be
    // straightforward. TDD will have a much different feel, so please try this for an assignment or in
    // lab where tests are required.
    
    // This is the only test we implemented. I wanted to highlight the benefits of a test suite, so all
    // tests were implemented there.
    TestQueue().testEnqueueEmpty();
    
    return 0;
}
