//
//  Node.hpp
//  Lab 8 '25
//
//  Created by Kyle Parker on 3/3/25.
//

#ifndef Node_hpp
#define Node_hpp

// Nothing special here

#include <string>

using std::string;

class Node {
    string _data;
    Node* _next;
    
public:
    Node(const string& data) : _data(data), _next(nullptr) {}
    
    Node* next();
    
    void setNext(Node* newNext);
    
    string data();
};

#endif /* Node_hpp */
