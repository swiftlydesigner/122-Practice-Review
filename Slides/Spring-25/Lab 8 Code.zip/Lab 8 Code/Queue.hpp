//
//  Queue.hpp
//  Lab 8 '25
//
//  Created by Kyle Parker on 3/3/25.
//

#ifndef Queue_hpp
#define Queue_hpp

// See the note regarding the two getters. Refer to the CPP file for an explanation of std::optional.
// I also show an example of in-line documentation.

#include <optional>

#include "Node.hpp" // Node, string

using std::optional;

class Queue {
    Node * _head;
    Node * _tail;
    
    void _print(Node * current);
    
    void _destroyQueue();
    
public:
    Queue() : _head(nullptr), _tail(nullptr) {}
    
    ~Queue();
    
    bool isEmpty();
    
    bool enqueue(const string& data);
    
    optional<string> dequeue();
    
    void print();
    
    // Note: The following is exclusively for testing, as I was using a test suite where I
    // cannot use the friend operator. This should never reach production code. If you are
    // unfamiliar with production code, it simply refers to the code that is used by the
    // consumer. Furthermore, this exposes the internal workings of the structure, possibly
    // introducing a security risk.
    
    // Side note (unrelated to the variables below): We always assume a non-technical user
    // when writing documentation because technical users will rarely have problems with
    // good software. However, if we write technical documentation that a fellow programmer
    // will understand, a non-technical user will likely not fully comprehend it. For example,
    // if I write software for a home router, I also need to provide documentation. Let's say
    // I write,
    // "Problem: Network packets cannot find a route to the next hop.
    //  Solution: Ensure the gateway address is correct by logging in to the local management console."
    // While this is documentation, it is still part of Software Engineering.
    
    // Used for testing:
    Node* head() { return _head; }
    Node* tail() { return _tail; }
};

#endif /* Queue_hpp */
