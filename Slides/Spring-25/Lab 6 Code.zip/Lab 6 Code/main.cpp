//
//  main.cpp
//  Lab 6 Code
//
//  Created by Kyle Parker on 2/17/25.
//

#include <iostream>
#include <vector>
#include <string>

// Note: We do not include Node.hpp
#include "Stack.hpp" // Stack
#include "Utilities.hpp" // utils namespace

using std::vector;
using std::string;
using std::endl;
using std::cout;

int main(int argc, const char * argv[]) {
    /// Here, we will reverse a string, character by character using a vector.
    /// I opted this route so you can be introduced to a vector.
        vector<char> reversedBase64 = { 'K', 'E', 'y', 'a', 'j', 'F', 'G', 'd', 'T', 'B', 'y', 'K', 'm', 'r', 'I', 'E', 's', '8', 'G', 'b', 's', 'V', 'G', 'S' };
    
        // Question: What is the type for this Stack?
        Stack reverseBase64Stack(reversedBase64);
    
        string forwardString = "";
    
        while (!reverseBase64Stack.isEmpty()) {
            char c;
    
            reverseBase64Stack.pop(c);
    
            forwardString += c;
        }
    
        cout << "Forward String value: `" << forwardString << "`" << endl;
        cout << "Use base64 decoder to see plain-text" << endl;
    
    
        /// Another stack example:
    
        Stack<int> s1;
    
        s1.push(2);
        s1.push(4);
        s1.push(8);
        s1.push(12);
    
        int temp = 0, sum = 0;
    
        cout << "Sum of ";
    
        while (!s1.isEmpty()) {
            s1.pop(temp);
    
            cout << temp << " + ";
    
            sum += temp;
        }
    
        cout << "= " << sum;
    
    
    // Exception handling:
    string validFloat = "125.2";
    string invalidFloat = "some";
    
    try {
        cout << std::stof(validFloat) << endl;
        cout << std::stof(invalidFloat) << endl; // Will throw error and jump to catch
    } catch (std::exception& exc) {
        cout << "Error parsing float!" << endl;
    }
    
    string validInt = "124";
    string invalidInt = "other";
    
    try {
        cout << std::stoi(validInt) << endl;
        cout << std::stoi(invalidInt) << endl; // Will throw error and jump to catch
    } catch (std::exception& exc) {
        cout << "Error parsing int!" << endl;
    }
    
    
    /// Here, I externalize the algorithm I discussed at the end of lab. I breifly commented it.
    ///
    /// Note: I created my own namespace with a nested namespace to clearly show getIntFromUser
    /// is an IO operation in the scheme in utilities.
    int userSelection = utils::io::getIntFromUser();
    
    return 0;
}
