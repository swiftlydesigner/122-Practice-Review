//
//  Node.cpp
//  Lab 6 Code
//
//  Created by Kyle Parker on 2/17/25.
//

#include "Node.hpp"

/// Constructor with some type T, we do not know what
/// the type is, but we can think of it being an int or a
/// string. We do not need to know the type up front,
/// we only need to have some placeholder for the type.
///
/// @Param newData The data to initalize this node
template <typename T>
Node<T>::Node(const T& newData) {
    // Recall our members:
    //    T _data;
    //    Node<T> * _next;
    
    // Validation?
    
    _data = newData;
    
    _next = nullptr;
    
}

/// Copy constructor. `this` does NOT exist yet, `existingNode` does exist.
///
/// @Param existingNode The node to copy from
template <typename T>
Node<T>::Node(const Node& existingNode) {
    // Recall our members:
    //    T _data;
    //    Node<T> * _next;
    
    
    _data = existingNode._data;
    _next = nullptr;
    
}

/// Overloaded assignment operator. `this` and `rhs` both exist
///
/// @Param rhs The node to copy from
template <typename T>
Node<T>& Node<T>::operator=(const Node& rhs) {
    // Recall our members:
    //    T _data;
    //    Node<T> * _next;
    
    _data = rhs._data;
    _next = nullptr;
}

/// Destructor.
///
/// We will destory any memory that was allocated here.
template <typename T>
Node<T>::~Node() {
    // Recall our members:
    //    T _data;
    //    Node<T> * _next;
    
    // Is there anything to do?
    // Nothing to cleanup
}

/// Set the next pointer on a node.
///
/// @Param newNext The new next pointer
template <typename T>
void Node<T>::setNext(Node<T>* newNext) {
    // Recall our members:
    //    T _data;
    //    Node<T> * _next;
    
    _next = newNext;
}

/// Get the next pointer for a node.
///
/// @Returns The next node in series
template <typename T>
Node<T>* Node<T>::next() {
    // Recall our members:
    //    T _data;
    //    Node<T> * _next;
    
    return _next;
}

/// Get the data in this node.
///
/// Note: If T is a custom type we make, the copy constructor MUST exist!
///
/// @Returns The data contained in this node.
template <typename T>
T Node<T>::data() {
    // Recall our members:
    //    T _data;
    //    Node<T> * _next;
    
    return _data;
    
}
