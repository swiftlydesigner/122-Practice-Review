//
//  Utilities.cpp
//  Lab 6 Code
//
//  Created by main on 2/18/25.
//

#include <iostream>
#include "Utilities.hpp"

/// Use getIntFromUser(), and validate it is within the range, min max, inclusive.
///
/// @param min The min value to accept
/// @param max The max value to accept
///
/// @Returns A valid value from the user between min and max.
int utils::io::getIntFromUser(int min, int max) {
    int input = getIntFromUser();
    
    while (input < min || input > max) {
        input = getIntFromUser();
    }
    
    return input;
}

/// This function will return an integer, which has been validated from the user.
///
/// @Returns A valid integer
int utils::io::getIntFromUser() {
    // Declare all vars at the top
    bool read = false;
    std::string userInput;
    int selectedOption = 0;
    
    while (!read) {
        
        std::getline(std::cin, userInput);
        // Get user input here
        
        try {
            selectedOption = std::stoi(userInput);
            read = true;
        } catch (std::exception& exc) {
            // Print the error on the standard error stream.
            std::cerr << "Please enter an integer!";
        }
    }
    
    return selectedOption;
}
