//
//  StackTest.hpp
//  Lab 6 Code
//
//  Created by main on 2/17/25.
//

#ifndef StackTest_hpp
#define StackTest_hpp

#include <iostream>

#include "Stack.hpp" // UUT

using std::cout;
using std::endl;

#define FUNC_NAME '[' << __FUNCTION__ << ':' << __LINE__ << "] "

class StackTest final {
    Stack<int> _uut;
    
    void setup() {
        // Reset stack
        _uut = Stack<int>();
    }

public:
    void runAllTests() {
        // Test push 0, 1 existing elements
        // Testing with 1+ elements should have the same behavior.
        testPushEmpty();
        testPushOneElement();
        
        // Test pop 0, 1, 2 elements
        // Note: pop 0 is only needed for defensive programming
        // Testing with 2+ elements should all have the same behavior.
        testPopEmpty();
        testPopOneElement();
        testPopTwoElement();
    }
    
    void testPushEmpty() {
        setup();
        
        const int newData = 30;
        
        _uut.push(newData);
        
        if (_uut.top != nullptr) {
            cout << FUNC_NAME << "top is valid (non-null)." << endl;
            
            if (_uut.top->data() == newData) {
                cout << FUNC_NAME << "Success! values match!" << endl;
            } else {
                cout << FUNC_NAME << "Fail. Top's data is wrong. Expected " << newData << ", but got " << _uut.top->data() << endl;
            }
            
            if (_uut.top->next() == nullptr) {
                cout << FUNC_NAME << "Success! top's next is nullptr!" << endl;
            } else {
                cout << FUNC_NAME << "Fail. Top's next is non-null. Expected nullptr, but got " << _uut.top->next() << endl;
            }
            
        } else {
            cout << FUNC_NAME << "Fail. top is invalid (null)." << endl;
        }
    }
    
    /// We assume testPushEmpty() has been called and has passed.
    void testPushOneElement() {
        setup();
        
        const int bottomEle = 30;
        const int topEle = 60;
        
        _uut.push(bottomEle); // Already tested
        
        _uut.push(topEle); // We need to test this call
        
        if (_uut.top != nullptr) {
            cout << FUNC_NAME << "top non-null (good)." << endl;
            
            // Test top's data
            if (_uut.top->data() == topEle) {
                cout << FUNC_NAME << "Success! values match!" << endl;
            } else {
                cout << FUNC_NAME << "Fail. Top's data is wrong. Expected " << topEle << ", but got " << _uut.top->data() << endl;
            }
            
            // Test top's next non-null
            
            // Using auto incase we change the template type
            const auto next = _uut.top->next();
            
            if (next != nullptr) {
                cout << FUNC_NAME << "top's next is non-null (good)." << endl;
                
                if (next->data()) {
                    cout << FUNC_NAME << "top's next->data is good!" << endl;
                } else {
                    cout << FUNC_NAME << "Fail. Top's next->data should be " << bottomEle << ", but is " << next->data() << endl;
                }
                
                if (next->next() == nullptr) {
                    cout << FUNC_NAME << "top's next->next() is null!" << endl;
                } else {
                    cout << FUNC_NAME << "Fail. Top's next->next() should be nullptr, but is " << next->next() << endl;
                }
                    
            } else {
                cout << FUNC_NAME << "Fail. top's next is invalid (null)." << endl;
            }
            
        } else {
            cout << FUNC_NAME << "Fail. top is invalid (null)." << endl;
        }
    }
    
    void testPopEmpty() {
        setup();
        
        int expected = int();
        int actual = -1;
        
        _uut.pop(actual);
        
        if (actual != expected) {
            cout << FUNC_NAME << "Fail. Expected " << expected << ", but got " << actual << endl;
        } else {
            cout << FUNC_NAME << "Pass! Default value returned!" << endl;
        }
    }
    
    
    // testPushEmpty must pass before running this test.
    void testPopOneElement() {
        setup();
        
        const int expected = 20;
        int actual = 0;
        
        _uut.push(expected); // Already tested
        
        _uut.pop(actual);
        
        if (_uut.top == nullptr) {
            cout << FUNC_NAME << "Top set to null!" << endl;
            
            if (actual == expected) {
                cout << FUNC_NAME << "Pass! Good return value!" << endl;
            } else {
                cout << FUNC_NAME << "Fail. Return value is incorrect!" << endl;
            }
            
        } else {
            cout << FUNC_NAME << "Fail. Top set is not null." << endl;
        }
    }
    
    // testPushOneElement must pass before running this test.
    void testPopTwoElement() {
        setup();
        
        const int expectedTop = 20;
        const int expectedPopped = 30;
        int actual = 0;
        
        _uut.push(expectedTop); // Already tested
        _uut.push(expectedPopped); // Already tested
        
        _uut.pop(actual);
        
        if (_uut.top != nullptr) {
            cout << FUNC_NAME << "Top is non-null!" << endl;
            
            // Test return value
            if (expectedPopped == actual) {
                cout << FUNC_NAME << "Good return value!" << endl;
            } else {
                cout << FUNC_NAME << "Fail. Return value is incorrect from pop! Got " << actual << ", but expected" << expectedPopped << endl;
            }
            
            // Test next value
            
            if (_uut.top->next() == nullptr) {
                cout << FUNC_NAME << "Top's next is nullptr!" << endl;
            } else {
                cout << FUNC_NAME << "Fail. Top's next is non-null. Expected nullptr, but got " << _uut.top->next() << endl;
            }
            
            // Test top's value
            if (_uut.top->data() == expectedTop) {
                cout << FUNC_NAME << "Success! values match!" << endl;
            } else {
                cout << FUNC_NAME << "Fail. Top's data is wrong. Expected " << expectedTop << ", but got " << _uut.top->data() << endl;
            }
            
        } else {
            cout << FUNC_NAME << "Fail. Top set is null, expected non-null." << endl;
        }
    }
    
    
};

#endif /* StackTest_hpp */
