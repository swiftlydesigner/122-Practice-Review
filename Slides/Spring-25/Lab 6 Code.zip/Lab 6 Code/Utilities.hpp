//
//  Utilities.hpp
//  Lab 6 Code
//
//  Created by main on 2/18/25.
//

#ifndef Utilities_hpp
#define Utilities_hpp

namespace utils {
    namespace io {
        int getIntFromUser(int min, int max);
        int getIntFromUser();
    }
}

#endif /* Utilities_hpp */
