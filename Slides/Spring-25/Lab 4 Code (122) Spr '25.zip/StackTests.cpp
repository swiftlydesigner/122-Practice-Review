//
//  StackTests.cpp
//  Test Function Example
//
//  Created by Kyle Parker on 2/4/25.
//

#include "StackTests.hpp"


/// Test the function `push` when the stack has at least one element already.
/// Here, we test by *manually* inserting some data, then call push.
/// We have to manually insert data because there is no other way we can
/// ensure items are added to the stack properly.
void testPushOnNotEmpty(void) {
    bool success = true;
    
    // Local member s, a Stack
    Stack s = { .top = NULL };
    
    Data bottom = { .myInt = 5 };
    
    // Allocate space for a new node to maually
    // insert into the stack.
    Node * newBottom = (Node*)malloc(sizeof(Node));
    newBottom->data = bottom;
    
    // Set the stacks's top pointer to the new bottom.
    // After a successful call to push, newBottom should
    // be the element below s.top.
    s.top = newBottom;
    
    // MARK: - Stack has one element at this point.
    // MARK: Begin testing for push w/ one element
    
    // The data we want to insert
    Data top = { .myInt = 10 };
    
    // Capture the return value of push, we will need this.
    // Note: Some of you may have push() be a void function.
    // If it returns void, you do not need to capture the
    // return value.
    bool returnValue = push(&s, top);
    
    // Ensure the push function returns true.
    // Note: If your push() returns void, you can skip this
    // check.
    if (returnValue == true) {
        printf("[testPushOnNotEmpty] Return value good.\n");
    } else {
        printf("[testPushOnNotEmpty] Return value bad.\n");
        success = false;
    }
    
    // This will stop execution if the returnValue is false.
    assert(success);
    
    // We need to ensure the stack's top is non-null
    if (s.top != NULL) {
        printf("[testPushOnNotEmpty] pTop is not NULL.\n");
    } else {
        printf("[testPushOnNotEmpty] pTop is NULL.\n");
        success = false;
    }
    
    // This will stop execution if s.top is NULL.
    assert(success);
    
    // We need to make sure the data on the top is set
    // correctly. The node was allocated and verified with
    // the past statement.
    if (s.top->data.myInt == top.myInt) {
        printf("[testPushOnNotEmpty] Data inserted correctly.\n");
    } else {
        printf("[testPushOnNotEmpty] Data was not inserted.\n");
        success = false;
    }
    
    // This will stop execution if the inserted data is NOT
    // what we expected it to be.
    assert(success);
    
    // Ensure the next element in the stack is the
    // newBottom. While the ADT for a stack declares we
    // can only view the top element, we need to verify
    // the top is linked to the next node correctly.
    if (s.top->next == newBottom) {
        printf("[testPushOnNotEmpty] Next was set correctly.\n");
    } else {
        printf("[testPushOnNotEmpty] Next was set incorrectly.\n");
        success = false;
    }
    
    // This will stop execution if next is NOT set to correct
    // node.
    assert(success);
    
    // Message the overall success of this test. If at
    // least one step fails, it will be reported here.
    if (success) {
        printf("[testPushOnNotEmpty] Test Passed!\n\n\n");
    } else {
        printf("[testPushOnNotEmpty] Test Failed!\n\n\n");
    }
}

