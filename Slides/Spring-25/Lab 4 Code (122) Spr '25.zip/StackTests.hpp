//
//  StackTests.hpp
//  Test Function Example
//
//  Created by Kyle Parker on 2/4/25.
//

#ifndef StackTests_hpp
#define StackTests_hpp

#include <stdio.h>   // printf
#include <stdlib.h>  // malloc
#include <assert.h>  // assert
#include <stdbool.h> // bool

#include "Stack.hpp" // Unit Under Test (UUT)

void testPushOnNotEmpty(void);

#endif /* StackTests_hpp */
