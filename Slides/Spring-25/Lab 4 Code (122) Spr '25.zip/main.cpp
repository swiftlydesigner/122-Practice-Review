//
//  main.cpp
//  Test Function Example
//
//  Created by Kyle Parker on 2/4/25.
//

#include "StackTests.hpp"

int main(int argc, const char * argv[]) {
    
    testPushOnNotEmpty();
    
    return 0;
}
