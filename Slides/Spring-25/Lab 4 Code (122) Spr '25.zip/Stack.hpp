//
//  Stack.hpp
//  Test Function Example
//
//  Created by Kyle Parker on 2/4/25.
//

#ifndef Stack_hpp
#define Stack_hpp

#include <stdio.h>

// We use this so we can easily change the data.
// C++: `class Data final { };`
// In C++, we will add operations to this class (getters & setters)
typedef struct _data {
    int myInt;
} Data;

// Node will only have a self reference and
// a Data attribute.
// C++: `class Node final { };`
// In C++, we will add operations to this class (getters & setters)
typedef struct _node {
    Data data;
    struct _node * next;
} Node;

// This will only conain top
// C++: `class Stack final { };`
// In C++, we will add operations to this class (push, pop, isEmpty, peek)
typedef struct _stack {
    Node * top;
} Stack;

// This was inlined to streamline the code process.
// Note: This will not pass the pushOnEmpty() test.
// Think about how you would need to change this.
inline bool push(Stack * s, Data d) {
    // Create a new node.
    // Note: best practices are not shown here.
    // Please make sure you can see the problem.
    Node * mem = (Node*)malloc(sizeof(Node));
    mem->data = d;
    mem->next = NULL;
    
    bool success = false;
    
    // If the top is non-NULL, insert this to the list
    if (s->top) {
        mem->next = s->top;
        s->top = mem;
        success = true;
    }
    
    // Is there an easy way to *adapt* this code to insert
    // mem into the stack when s->top is NULL?
    
    return success;
}
#endif /* Stack_hpp */
