//
//  Stack.hpp
//  Lab 6 Code
//
//  Created by Kyle Parker on 2/17/25.
//

#ifndef Stack_hpp
#define Stack_hpp

#include <vector>
#include "Node.hpp"

using std::vector;

/* ************************************************************* *
 * This is a template class, so we have template <typename T>.   *
 * a template class allows it to accept any type, which will     *
 * replace T at complile time. That is, if we make this a node   *
 * for a string, we will have `string _data` without explicitly  *
 * writing this class for a string.                              *
 *                                                               *
 * Stack will be using Node and managing dynamic memory. Recall  *
 * we use new and delete in C++. new and delete call our         *
 * constructor and destructors. malloc() and free() do not, so   *
 * there is a slight difference.                                 *
 *                                                               *
 * I will be using this style for the rest of the semester:      *
 *   - _lowerCamelCase preceded by an underscore for private     *
 *   - UpperCamelCase for types (i.e., Node) !!!                 *
 *   - lowerCamelCase for functionNames !!!                      *
 *   - lowerCamelCase for getters (name of private var, minus _) *
 *   - Setters will use: `void set<VAR>(<TYPE>& new<VAR>)`       *
 *   - Always include the big three !!!                          *
 * ************************************************************* */

template <typename T>
class Stack final {
    // Private
    Node<T> * top;
    
    void destroyStack();
    
public:
    Stack(const vector<T>& dataVector = {});
    
    // Big three: Copy Constructor
    Stack(const Stack<T>& existingStack);
    
    // Big three: Overloaded = operator
    Stack<T>& operator=(const Stack<T>& rhs);
    
    // Big three: Destructor
    ~Stack();
    
    void push(const T& data);
    
    void pop(T& data);
    
    void peek(T& data);
    
    bool isEmpty();
    
    friend class StackTest;
};

#endif /* Stack_hpp */
