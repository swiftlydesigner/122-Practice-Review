//
//  main.cpp
//  Lab 6 Code
//
//  Created by Kyle Parker on 2/17/25.
//

#include <iostream>
#include <vector>
#include <string>

// Note: We do not include Node.hpp
#include "Stack.hpp" // Stack

using std::vector;
using std::string;
using std::endl;
using std::cout;

int main(int argc, const char * argv[]) {
    /// Here, we will reverse a string, character by character using a vector.
    /// I opted this route so you can be introduced to a vector.
    vector<char> reversedBase64 = { 'K', 'E', 'y', 'a', 'j', 'F', 'G', 'd', 'T', 'B', 'y', 'K', 'm', 'r', 'I', 'E', 's', '8', 'G', 'b', 's', 'V', 'G', 'S' };
    
    // Question: What is the type for this Stack?
    Stack reverseBase64(reversedBase64);
    
    string forwardString = "";
    
    while (!reverseBase64.isEmpty()) {
        char c;
        
        reverseBase64.pop(c);
        
        forwardString += c;
    }
    
    cout << "Forward String value: `" << forwardString << "`" << endl;
    cout << "Use base64 decoder to see plain-text" << endl;
    
    
    /// Another stack example:
    
    Stack<int> s1;
    
    s1.push(2);
    s1.push(4);
    s1.push(8);
    s1.push(12);
    
    int temp = 0, sum = 0;
    
    cout << "Sum of ";
    
    while (!s1.isEmpty()) {
        s1.pop(temp);
        
        cout << temp << " + ";
        
        sum += temp;
    }
    
    cout << "= " << sum;
    
    
    return 0;
}
