//
//  Stack.cpp
//  Lab 6 Code
//
//  Created by Kyle Parker on 2/17/25.
//

#include "Stack.hpp"

/// MARK: - Private Functions

/// We will destroy the stack.
template <typename T>
void Stack<T>::destroyStack() {
    // Recall our member:
    //    Node<T> * top;
}

/// MARK: - Public Functions

/// The constructor which accepts a vector of data (type T) to insert into this list.
///
/// @Param dataVector [optional] A vector of data points to insert
template <typename T>
Stack<T>::Stack(const vector<T>& dataVector) {
    // Recall our member:
    //    Node<T> * top;
    
    // for-each style loop which holds a reference of type
    // T to each position in the vector. Simply put, iterate
    // through the vector of items passed in, never making a
    // copy of data (if it was a large data type and we have
    // 10000 elements, that would take a long time, a lot of
    // memory, and a lot of resources). Use reference ensures
    // we only copy the value once, when we create the node!
    for (auto& ele : dataVector) {
        
    }
}

/// Copy Constructor. `this` does not exist, `existingStack` exists.
///
/// @Param existingStack The stack to copy from.
template <typename T>
Stack<T>::Stack(const Stack<T>& existingStack) {
    // Recall our member:
    //    Node<T> * top;
    
}

/// Overloaded = operator. `this` and `existingStack` exist.
///
/// @Param rhs The stack to copy from.
template <typename T>
Stack<T>& Stack<T>::operator=(const Stack<T>& rhs) {
    // Recall our member:
    //    Node<T> * top;
    
    // Is there anything we need to do before copying over?
}

/// Destructor. Here, we will destory the stack and clear all memory
template <typename T>
Stack<T>::~Stack() {
    // Recall our member:
    //    Node<T> * top;
    
    
}

/// Push an element, `data` to the stack
///
/// @Param data The data to push
template <typename T>
void Stack<T>::push(const T& data) {
    // Recall our member:
    //    Node<T> * top;
    
    
}

/// Pop an element, `data` from the stack.
/// Not all implementations of a stack will have
/// a return value or return parameter. I choose to
/// do so based on preference.
///
/// @Param data Output parameter
template <typename T>
void Stack<T>::pop(T& data) {
    // Recall our member:
    //    Node<T> * top;
    
    
}

/// Look at the top element.
///
/// @Param data Output parameter
template <typename T>
void Stack<T>::peek(T& data) {
    // Recall our member:
    //    Node<T> * top;
    
    
}

/// Determine if the stack is empty.
///
/// @Returns Boolean indicating if this stack is empty.
template <typename T>
bool Stack<T>::isEmpty() {
    // Recall our member:
    //    Node<T> * top;
    
    
}
