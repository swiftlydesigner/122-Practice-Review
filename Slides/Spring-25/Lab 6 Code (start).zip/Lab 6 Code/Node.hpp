//
//  Node.hpp
//  Lab 6 Code
//
//  Created by Kyle Parker on 2/17/25.
//

#ifndef Node_hpp
#define Node_hpp

/* ************************************************************* *
 * This is a template class, so we have template <typename T>.   *
 * a template class allows it to accept any type, which will     *
 * replace T at complile time. That is, if we make this a node   *
 * for a string, we will have `string _data` without explicitly  *
 * writing this class for a string.                              *
 *                                                               *
 * This class is entirely managed by Stack, so nobody except     *
 * Stack should be calling these public functions.               *
 *                                                               *
 * I will be using this style for the rest of the semester:      *
 *   - _lowerCamelCase preceded by an underscore for private     *
 *   - UpperCamelCase for types (i.e., Node) !!!                 *
 *   - lowerCamelCase for functionNames !!!                      *
 *   - lowerCamelCase for getters (name of private var, minus _) *
 *   - Setters will use: `void set<VAR>(<TYPE>& new<VAR>)`       *
 *   - Always include the big three !!!                          *
 * ************************************************************* */

template <typename T>
class Node final {
    T _data;
    
    Node<T> * _next;
    
public:
    Node(const T& newData);
    
    // Big three: Copy Constructor
    Node(const Node& existingNode);
    
    // Big three: Overloaded = operator
    Node<T>& operator=(const Node& rhs);
    
    // Big three: Destructor
    ~Node();
    
    void setNext(Node<T>* newNext);
    
    Node<T>* next();
    
    T data();
};

#endif /* Node_hpp */
