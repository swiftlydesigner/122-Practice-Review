//
//  Complex.cpp
//  C++ Intro Spr '25
//
//  Created by main on 2/11/25.
//

#include "Complex.hpp"

// MARK: - Begin member functions

// We no longer need the below constructor because we have
// a constructor with default aguments (see HPP).
// Constructor
//Complex::Complex() {
//    real = 0;
//    imag = 0;
//}

/// This is declared as `Complex(double newImag = 0, double newReal = 0)`,
/// but defined as `Complex(double newImag, double newReal)`. Be sure you only
/// put default values in the header file. If you put default values only in or also in the
/// CPP file, the program will not build.
///
/// This is a constructor which accepts the following arguments: (<NONE>), (int), and (int, int)
/// If we provide no arguments, `newImag` and `newReal` will have a value of 0.
/// If we provide a single argument, it will go to `newImag`. `newReal` will have a value of 0 while `newImag` will have the value passed.
/// If we provide two arguments, the value will go to the respective argument as it has in C.
/// @Param newImag the imaginary part
/// @Param newReal the real part
Complex::Complex(double newImag, double newReal) {
    /// I use `this` throughout my code as that is the style I prefer to use. There are
    /// few circumstances that require the use of `this`.
    this->imag = newImag;
    this->real = newReal;
}

/// This function is a **member** of `Complex`, therefore we need to use `Complex::`
/// to indicate it is a part of Complex and not a global or non-member function.
///
/// Note how I use const. This is explicitly showing that other will never be modified. Some
/// students believe if they never make changes to the object, then there is no need to mark
/// it as const. This is poor practice. Be sure you explictly mark objects as const when you do
/// not intend to make changes to it. This is a very important practice. Some coding standards
/// may require the use of const whenever the object is not intended to be modified.
///
/// I also pass by reference here. This is to save memory and reduce the number of copies made.
///
/// @Warning The instance which this function was called upon will be modified!
/// @Param other The Complex value to sum with.
/// @Return A copy of the instance this function was invoked on.
//RETURN TYPE   CLASS   FUNC         ARGS
Complex        Complex::add  (const Complex& other) {
    // Example call: c3 = c1.add(c2);
    // We are going to make changes to c1
    //
    // c3 and c1 will hold the same values,
    // but are **different** objects

    
    /// **Important note: other is a constant Complex** This means that it can only call
    /// functions marked as const. See below for what this means.
    this->imag += other.getImag();
    this->real += other.getReal();
    
    /// Return a copy of `this` instance. `this` is a pointer to the current object in memory.
    /// When we derefrence it, we have a `Complex` (i.e., we went down one level of indirection
    /// from `Complex *` to `Complex`. Then, we return a copy. In C++ a copy constructor is
    /// invoked to handle this (see HPP for deatils).
    return *this;
}

/// This will return the value of imag.
///
/// This is a constant function which means it **cannot** modify anything within Complex.
/// We can read everything from Complex, but we cannot write to anything. That also means
/// we cannot call non-const function from here. The const qualifier can always be added to
/// something, but it can never be removed.
///
/// @Return A copy of `imag`
double Complex::getImag() const {
    return imag;
}

/// This will return the value of real.
///
/// This is a constant function which means it **cannot** modify anything within Complex.
/// We can read everything from Complex, but we cannot write to anything. That also means
/// we cannot call non-const function from here. The const qualifier can always be added to
/// something, but it can never be removed.
///
/// @Return A copy of `real`
double Complex::getReal() const {
    return real;
}

// MARK: - Begin non-member functions

// Non-member add
/// This is a non-member function which accepts two references to a constant `Complex`.
/// *This is different than a constant reference to a Complex; we cannot have a constant reference.*
/// This means that we cannot call add on `lhs` or `rhs`. As such, we will create a copy of `lhs`
/// (by explicitly invoking the copy constructor). We then return the value of `c.add(rhs)` as add
/// returns the value of `lhs` + `rhs`.
///
/// Note: being non-member, this is **not** function overloading and we do not have access to
/// `Complex.real` directly; we must call `.getReal()`.
///
/// @Param lhs The first param to be added.
/// @Param rhs The second param to be added.
/// @Return A `Complex` result of the two Complex numbers, summed.
Complex add(const Complex& lhs, const Complex& rhs) {
    Complex c(lhs);
    
    return c.add(rhs);
}

// Non-member operator overload
//                          c1       +        c2
/// Suppose we have a call as such: `c3 = c1 + c2`. The return value will be put in `c3`, `lhs`
/// has a reference to `c1`, and `rhs` has a reference to `c2`. As you can see, we use exisitng
/// implementation to keep the function short and simple. This increases maintainability and readability.
///
/// @Param lhs The left hand side of the + operator
/// @Param rhs The right hand side of the + operator
/// @Return A new object with the sum.
Complex operator+(const Complex& lhs, const Complex& rhs) {
    return add(lhs, rhs);
}
