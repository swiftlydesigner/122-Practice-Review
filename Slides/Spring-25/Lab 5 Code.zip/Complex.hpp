//
//  Complex.hpp
//  C++ Intro Spr '25
//
//  Created by main on 2/11/25.
//

#ifndef Complex_hpp
#define Complex_hpp

/// See CPP file for detailed comments.

class Complex {
    /// Here, we have have two private doubles.
    double imag;
    double real;
    
public:
    //Complex(); // Constructor
    
    // We define the default values here. They will always be in the HPP file
    Complex(double newImag = 0, double newReal = 0); // Argument
    
    /// MARK: - BEGIN FEB 12th
    /// Here is what we covered in lecture today, Wed, Feb 12th. I have defined everything
    /// in here to indicate it is new and was not covered during lab.
    
    /// This is the copy constructor. It should be const and it MUST be by reference. We are defining
    /// how to handle a copy of the object, so we cannot pass by value as that copies the object and
    /// we are defining that right now.
    ///
    /// @Param rhs The existing Complex object.
    Complex(const Complex& rhs) {
        this->imag = rhs.imag;
        this->real = rhs.real;
    }
    
    /// This is the overloaded assignment operator. That means `this` and `rhs` both exist in memory.
    /// This is an overloaded operator, not a constructor! We want to copy everything from `rhs` to `this`
    Complex operator=(const Complex& rhs) {
        /// If these two objects are not the same, then we will copy.
        /// If they are the same object, we simply return `*this`.
        if (this != &rhs) {
            this->imag = rhs.imag;
            this->real = rhs.real;
        }
        
        /// Return a copy of this instance
        return *this;
    }
    
    /// Destructor. This will **never** accept arguments. This can be marked as virtual (related to polymorphism).
    /// This is where we would deallocate any memory that has been allocated or close files. In this specific example,
    /// there is nothing to cleanup, so it is empty. If you want to implement your destructor in you HPP file (when it is empty),
    /// that is acceptable.
    ~Complex() {
        // Deallocate memory used
        
        // Close files
        
        // Cleanup Complex
    }
    
    /// MARK: - END FEB 12th
            
    Complex add(const Complex& other);
    
    double getImag() const;
    double getReal() const;
};

Complex add(const Complex& lhs, const Complex& rhs);

//                          c1       +        c2
Complex operator+ (const Complex& lhs, const Complex& rhs);

#endif /* Complex_hpp */
