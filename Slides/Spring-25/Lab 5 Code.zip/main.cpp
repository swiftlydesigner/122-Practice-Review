//
//  main.cpp
//  C++ Intro Spr '25
//
//  Created by main on 2/11/25.
//

#include <iostream>
#include <string>

#include "Complex.hpp"

int main(int argc, const char * argv[]) {
    
    /// All three constructors calls below use the same constructor
    Complex c1(10, 2);
    
    Complex c2(10);
    
    Complex c3;
    
    // Define a string
    std::string str;
    
    /// Call getline. This is the C++ version of `fgets(myCStyleString, sizeof(myCStyleString), stdin)`.
    /// This will read until the new line (aka the user presses enter)
    std::getline(std::cin, str);
    
    /// We still have access to atoi and atof functions. But, as you see we need to use `str.c_str()` to get a C-style string.
    /// Sometimes we may need to use C-style string, but there is a much better and easier way in C++!
    int myInt1 = std::atoi(str.c_str());
    
    /// The C++ way to convert a string to integer. Note: This has the same limitations as atoi.
    ///
    /// Unlike atoi, stoi throws an exception. Exceptions allows us to stop execution and jump back through the call
    /// stack without completing a function call. We catch recoverable errors by using a try-catch statement.
    int myInt2 = std::stoi(str);
    
    /// Mark this block of code as a section which will attempt to run some code, knowing it could fail at some point.
    /// If it fails, go to the catch statement which matches the type (we will cover this later).
    try {
        /// Define an invalid string
        std::string myInvalidString = "Not an int";
        /// Attempt conversion
        int myIntInvalid = std::stoi(myInvalidString);
        
        /// This line will never be executed!
        myInt1 = 10;
        
        /// This catch statement is saying if the exception thrown is an `invalid_argument`, catch it here and execute this code
    } catch (std::invalid_argument& exc) {
        std::cout << "Something went wrong coverting the integer" << std::endl;
    }
    
    /// Here is an example of reading a double from `cin`. We simply use the stream extration operator (>>).
    double target = 0;
    std::cin >> target;
    
    /// Read a string upto the nearest white space (i.e., ` `, `\n`, `\t`, etc.)
    std::string str2;
    std::cin >> str2;
    
    /// Important note: We need to use std::getline() to read in an entire line. Then, to parse through the line,
    /// we will use std::string::substr. std::string::substr(int beginIndex, int length). We also need find. Look up
    /// the documentation for these, avoid using AI and get used to documentation until you are good.
    std::string subStringExample = "Here is my example";
    
    /// Find the index of is within subStringExample. This will return the index of the first occurence of "is"
    std::size_t indexOfIs = subStringExample.find("is");
    
    /// Get the substring from index 0, with length `indexOfIs`. In other words, get everything before the first occurence of "is"
    std::string subStr = subStringExample.substr(0, indexOfIs);
    

    std::cout << "One of many substrings of `" << subStringExample << "` is `" << subStr << "`." << std::endl;
    
    // 3
    // Today
    // 6
    
    /// We can also chain >>, but is does not always mix well when we switch between numerical types and strings.
    /// Play around with this and figure out how this works. Look into parsing a std::string.
    std::cin >> target >> str2 >> target;
    
    
    /// MARK: - Begin vectors
    
    /// Vectors are efficent and easy ways of storing data. Consider using this for PA 4. Look into details on your own.
    /// See below for an example of how we can add, remove, and iterate through a vector's content.
    std::vector<int> myVectorInts;
    
    myVectorInts.push_back(13);
    myVectorInts.push_back(12);
    myVectorInts.push_back(14);
    myVectorInts.push_back(11);
    myVectorInts.push_back(15);
    myVectorInts.push_back(10);
    myVectorInts.push_back(16);
    myVectorInts.push_back(9);
    
    std::cout << "Here is the content of my vector: ";
    
    /// A C++ style for-each loop:
    for (int currentInt : myVectorInts) {
        std::cout << currentInt << " --> ";
    }
    
    std::cout << "|||END|||" << std::endl;
    
    return 0;
}
