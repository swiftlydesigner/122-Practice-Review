//
// Created by main on 4/8/25.
//

#include "Person.h"
#include <sstream>

Person::Person(const std::string &newName, const int &newAge, const char &newGender, const Height &newHeight) {
    this->name = newName;
    this->age = newAge;
    this->gender = newGender;
    this->height = newHeight;
}

std::ostream & operator<<(std::ostream &lhs, const Person &rhs) {
    lhs << rhs.getName() << ",";
    lhs << rhs.getAge() << ",";
    lhs << rhs.getGender() << ',';
    lhs << rhs.getHeight() << ',';
    return lhs;
}

std::istream & operator>>(std::istream &lhs, Person &rhs) {
    std::string line;
    std::getline(lhs, line);

    std::string value;
    std::stringstream ss(line);
    std::vector<std::string> tokens;

    while (std::getline(ss, value, ',')) {
        tokens.push_back(value);
    }

    rhs.setName(tokens[0]);
    rhs.setAge(std::stoi(tokens[1]));
    rhs.setGender(tokens[2][0]);
    rhs.setHeight(Height(std::stof(tokens[3])));

    return lhs;
}

