//
// Created by main on 4/8/25.
//

#ifndef PERSON_H
#define PERSON_H

#include <ostream>
#include <string>

#include "Height.h"

class Person {
public:
    Person(): age(0), gender(0) {
    }

    Person(const std::string& newName,
           const int &newAge,
           const char &newGender,
           const Height &newHeight);

    Person(const Person& rhs);

    Person& operator=(const Person& rhs) {
        if (this != &rhs) {
            // copy constructor implementation here
        }
        return *this;
    }

    ~Person();

    auto getName() const -> const std::string & {
        return name;
    }

    auto getAge() const -> int {
        return age;
    }

    auto getGender() const -> char {
        return gender;
    }

    auto getHeight() const -> Height {
        return height;
    }

    void setName(const std::string& newName) {
        name = newName;
    }

    void setAge(const int &newAge) {
        if (age > 0) {
            age = newAge;
        }
    }

    void setGender(const char &newGender) {
        gender = newGender;
    }

    void setHeight(const Height &newHeight) {
        height = newHeight;
    }

private:
    std::string name;
    int age;
    char gender;
    Height height;
};

std::ostream& operator<<(std::ostream & lhs, const Person& rhs);
std::istream& operator>>(std::istream & lhs, Person& rhs);



#endif //PERSON_H
