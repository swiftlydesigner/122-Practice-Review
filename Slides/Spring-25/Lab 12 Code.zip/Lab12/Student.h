//
// Created by main on 4/8/25.
//

#ifndef STUDENT_H
#define STUDENT_H
#include "Person.h"

// Here, we will create a course struct.
// The student will manage what courses they have.
// Courses should be stored in an array. This means having `Course*` as the type and allocating space with new[],
// then deallocate with delete[]/

class Student : public Person {
    Student();
};



#endif //STUDENT_H