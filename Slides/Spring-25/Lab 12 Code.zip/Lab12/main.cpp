#include <iostream>

#include "Person.h"

int main() {
    std::cout << "Hello, World!" << std::endl;

    // Implicitly call `Height(const double& feetInches)`
    Height h = 62.2;

    std::cout << h << std::endl;

    return 0;
}
