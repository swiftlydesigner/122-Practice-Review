//
// Created by main on 4/8/25.
//

#ifndef TEACHER_H
#define TEACHER_H



// Similar to student, but we care about some other stats.

// Recall: weighted average = sum(weight * value) / sum(weight)

class Teacher {

};



#endif //TEACHER_H
