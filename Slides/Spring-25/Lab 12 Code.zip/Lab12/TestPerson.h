//
// Created by main on 4/8/25.
//

#ifndef TESTPERSON_H
#define TESTPERSON_H
#include "Person.h"

// Tests in here should be very basic and focus on how we can change the code
// when we change the private members to protected. Hint: this enables us to
// directly access the members, bypassing the getters. As we have been discussing
// in lecture, there are pros and cons to this.

class TestPerson : public Person {
public:
    TestPerson() /* implicitly calling Person() constructor */ = default;


};



#endif //TESTPERSON_H
