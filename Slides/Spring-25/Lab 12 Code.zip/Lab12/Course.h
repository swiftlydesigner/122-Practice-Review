//
// Created by main on 4/8/25.
//

#ifndef COURSE_H
#define COURSE_H
#include <string>

struct Course {
    Course(const std::string &newName, const int &newCredits, const int &newGrade) :
        name(newName), credits(newCredits), grade(newGrade) {}

    const std::string name;
    const int credits;
    const double grade;
};

#endif //COURSE_H
