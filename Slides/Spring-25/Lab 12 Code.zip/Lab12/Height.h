//
// Created by main on 4/8/25.
//

#ifndef HEIGHT_H
#define HEIGHT_H

struct Height {
    // Implicit use of this constructor can be found in main.
    Height(const double& feetInches) {
        feet = static_cast<int>(feetInches) % 12;
        inches = feetInches - feet * 12;
    }

    // Ensures this constructor is explicitly invoked.
    explicit Height(const int &newFeet = 0, const double &newInches = 0) {
        feet = newFeet;
        inches = newInches;
    }

    // Overloaded = operator
    Height& operator= (const Height& rhs) {
        if (this != &rhs) {
            feet = rhs.feet;
            inches = rhs.inches;
        }

        return *this;
    }

    // Public vars, since we are in struct, not class
    int feet;
    double inches;
};

// inline declaration of << op to display the Height object.
inline std::ostream& operator<<(std::ostream & lhs, const Height & rhs) {
    double height = rhs.feet * 12 + rhs.inches;
    lhs << height;
    return lhs;
}

#endif //HEIGHT_H
