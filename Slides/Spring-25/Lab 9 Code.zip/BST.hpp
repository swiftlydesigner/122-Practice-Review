//
//  BST.hpp
//  Lab 9
//
//  Created by main on 3/18/25.
//

#ifndef BST_hpp
#define BST_hpp

#include <functional>
#include <string>

#include "Node.hpp"

class Node; // Forward declaration

class BST {
    Node * _root;
    
    static void deleteFunc(Node*& node) {
        delete node;
        node = nullptr;
    }
    
    // Sample function which uses postOrderTraversal to delete the nodes.
    void destroyTree() {
        
        // Here is a lambda function which deletes all nodes. Observe how we look from the perspective of a single node.
        // This function is called for each node in the list, when passed into postOrderTraversal. The only difference from
        // `deleteNode` (a variable) and `deleteFunc` is their name. `deleteFunc` is the name of a function
        // whereas `deleteNode` is the name of a variable which holds a function.
        auto deleteNode = [](Node*& node) {
            delete node;
            node = nullptr;
        };
        
        // This destroys the tree by calling our lambda function.
        postOrderTraversal<Node*>(deleteNode, _root);
        
        // This destroys the tree by calling our **static** function. Although, with the call above, this technically does nothing.
        postOrderTraversal<Node*>(deleteFunc, _root);
    }
    
    template <typename T>
    // ** Change made from lab: second argument, pTree is now a T reference**
    
    // This is a generic function which accepts a parameter of types `std::function<void(T&)>` and `T&`.
    // Lets break down `std::function<void(T&)>`.
    // `std::function<>` is a type which references a function, whether it be a lambda or named function. A lambda
    // function is one which we declare inline, without having to write a function as have with everything in lab. In the `<>`,
    // we provide a return type and parameter type(s). In this case, we have a return type of void and a parameter of whatever we need.
    // The reason we use std::function is to have a single implemetation for many different operations.
    //
    // Most of the time, we will use a specific type for the parameter, not T. This is strictly for instructional purposes.
    //
    // As this function is now a template, in lab, I overlooked the specialization step of calling postOrderTraversal.
    // What does specialization mean? You have a generic function or class and give it a specific type. Code:
    //     `postOrderTraversal<Node*>(deleteFunc, pTree)`
    // Add angular brackets `<>` before the call and provide the type you want to work with.
    //
    // If we fail to use `<>`, then the compiler will not be able to assume the type since the expression is too complex.
    void postOrderTraversal(std::function<void(T&)> process, T& pTree) {
        if (pTree) {
            postOrderTraversal(process, pTree->left());
            postOrderTraversal(process, pTree->right());
            process(pTree);
        }
    }
    
    // inOrderTraversal accepts a function, I will call it a "handler", and a Node pointer. I pass in the handler so I can write a single
    // function for an inOrderTraversal.
    // Now, I can sum, print, concat, add elements to a vector (in order), or do whatever I want with this single function. To perform
    // these actions, I simply need to pass a function which will accomplish my task without rewriting inOrderTraversal.
    // For small programs, this is overkill and takes more time than it is worth. However, if you have a large project or something that
    // needs to be very flexible with handling, passing in std::function is a great option.
    void inOrderTraversal(std::function<void(std::string)> process, Node*& pTree) {
        if (pTree) {
            inOrderTraversal(process, pTree->left());
            process(pTree->data());
            inOrderTraversal(process, pTree->right());
        }
    }
    
    // This will insert newData into the current tree. In Node, I getLeft() and getRight() both return a `Node*&` which indicates it is reference.
    // This is a non-ideal approach since encapsulation is broken, but it also allows for a very simple insert function.
    void insert(const std::string& newData, Node*& current) {
        // Since we pass `current` by reference, this means we can modify any value by a simple assignment operator.
        if (current == nullptr) {
            current = new Node(newData);
            // No need to check for success because the program will crash if allocation fails.
            // In C++, an exception, `std::bad_alloc` will be thrown when memory is unavailable.
        } else if (newData < current->data()) {
            insert(newData, current->left());
        } else if (newData > current->data()) {
            insert(newData, current->right());
        }
    }
    
public:
    
    BST() {
        _root = nullptr;
    }
    
    ~BST() {
        destroyTree();
    }
    
    // Public interface of insert, the outside world only needs to know they are inserting a string.
    void insert(const std::string& newData) {
        insert(newData, _root);
    }
    
    // Public interface of inOrderTraversal, the outside world only passes in a handler of how to process the data.
    void inOrderTraversal(std::function<void(std::string)> func) {
        inOrderTraversal(func, _root);
    }
    
    template <typename T>
    // Public interface of postOrderTraversal, the outside world only passes in a handler of how to process the data.
    void postOrderTraversal(std::function<void(T)> process) {
        postOrderTraversal(process, _root);
    }
};

#endif /* BST_hpp */
