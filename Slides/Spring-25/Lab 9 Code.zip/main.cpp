//
//  main.cpp
//  Lab 9
//
//  Created by main on 3/18/25.
//

// Always place system headers before user-defined.
#include <iostream>
#include <vector>

#include "BST.hpp"
#include "Node.hpp"

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    
    std::vector<std::string> v;
    
    int counter = 0;
    
    // Print function defintion
    // This is a lambda function, which:
    //  1) Prints the data
    //  2) Counts how many nodes exist in the tree
    //  3) Pushes all strings in the tree to a vector, defined above.
    //          As we see below, we call inOrderTraveral, so we know the vector contains a sorted collection of strings.
    //
    // [&counter, &v] is the capture clause. This means we capture counter and v, by reference, allowing for changes to them.
    // If we do not declare anything in the capture clause, then it will not be visible. Since both counter and v are modified,
    // they must passed by reference. Otherwise, they would be immutable.
    //
    // (std::string str) is the parameter. This is no different than other functions.
    std::function<void(std::string)> printFunc = [&counter, &v](std::string str) {
        std::cout << counter << ") " << str << std::endl;
        ++counter;
        
        v.push_back(str);
    };
    
    BST bst;
    
    // Insert some data to the tree
    bst.insert("d");
    bst.insert("f");
    bst.insert("b");
    bst.insert("a");
    bst.insert("c");
    bst.insert("e");
    bst.insert("aa");
    
    // Handle the inorder traveral with the handler described above.
    bst.inOrderTraversal(printFunc);
    
    
    
    return 0;
}
