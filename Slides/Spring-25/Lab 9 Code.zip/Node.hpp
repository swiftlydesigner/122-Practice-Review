//
//  Node.hpp
//  Lab 9
//
//  Created by main on 3/18/25.
//

#ifndef Node_hpp
#define Node_hpp

#include <string>

class Node {
    Node* _left;
    Node* _right;
    std::string _data;
public:
    Node(const std::string& newData) {
        this->_data = newData;
        
        this->_left = this->_right = nullptr;
    }
    
    void setLeft(Node *& newLeft) {
        this->_left = newLeft;
    }
    
    void setRight(Node *& newRight) {
        this->_right = newRight;
    }
    
    void setData(const std::string& newData) {
        this->_data = newData;
    }
    
    // Returns a reference to the left poiner. This breaks the rules of encapsulation,
    // but enables us to write minimal lines in BST::insert
    Node*& left() {
        return this->_left;
    }
    
    // Returns a reference to the right poiner. This breaks the rules of encapsulation,
    // but enables us to write minimal lines in BST::insert
    Node*& right() {
        return this->_right;
    }
    
    std::string data() {
        return this->_data;
    }
};

#endif /* Node_hpp */
