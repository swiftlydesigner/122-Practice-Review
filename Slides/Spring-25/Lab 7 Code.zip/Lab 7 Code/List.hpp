//
//  List.hpp
//  Lab 7 Code
//
//  Created by Kyle Parker on 2/25/25.
//

#ifndef List_hpp
#define List_hpp

#include "ListNode.hpp"

class List {
    ListNode* _head;
    
    void _destroyList(ListNode* node) {
        if (node != nullptr) {
            _destroyList(node->next());
            delete node;
        }
    }
    
public:
    List() {
        _head = nullptr;
    }
    
    // List copy constructor
    List(const List& other) {
        // Important step: ensure `this` is not `other`
        if (this != &other) {
            // Destroy the list before we read in the new data
            _destroyList(_head);
            
            // Shallow:
//            this->_head = other.head();
            
            // Deep:
            this->_head = nullptr;

            ListNode * otherHead = other.head();

            while (otherHead) {
                insertEnd(otherHead->data());
                otherHead = otherHead->next();
            }
        }
    }
    
    // Destroy the list
    ~List() {
        _destroyList(_head);
    }
     
    // getter for the head
    ListNode* head() const {
        return _head;
    }
    
    // Insert at the end of the list
    bool insertEnd(const int& newData) {
        ListNode* pMem = new ListNode(newData);
        
        if (pMem) {
            ListNode* pCur = head();
            
            // Go to the end of the list
            while (pCur && pCur->next()) {
                pCur = pCur->next();
            }
    
            if (pCur) {
                pCur->setNext(pMem);
            } else {
                _head = pMem;
            }
        }
        
        return !!pMem;
    }
    
    // Give the non-member function debugPrintAddress full access, including private members.
    friend void debugPrintAddresses(List& list);
};

#endif /* List_hpp */
