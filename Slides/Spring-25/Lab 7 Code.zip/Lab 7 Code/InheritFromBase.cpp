//
//  InheritFromBase.cpp
//  Lab 7 Code
//
//  Created by Kyle Parker on 2/25/25.
//

#include "InheritFromBase.hpp"

void InheritFromBase:: test() {
    x = 10;
    print();
}
