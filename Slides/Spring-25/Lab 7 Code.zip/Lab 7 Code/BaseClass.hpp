//
//  BaseClass.hpp
//  Lab 7 Code
//
//  Created by Kyle Parker on 2/25/25.
//

#ifndef BaseClass_hpp
#define BaseClass_hpp

class BaseClass {
protected:
    int x;
    
    void print();
public:
    BaseClass(int x);
    void publicPrint();
};


#endif /* BaseClass_hpp */

