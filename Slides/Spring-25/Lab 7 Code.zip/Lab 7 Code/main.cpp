//
//  main.cpp
//  Lab 7 Code
//
//  Created by Kyle Parker on 2/25/25.
//

#include <iostream>
#include "List.hpp"
#include "InheritFromBase.hpp" // A quick discussion towards the end of lab

using std::endl;
using std::cout;

int main(int argc, const char * argv[]) {
    // insert code here...
//    List l1;
//    
//    List l2(l1);
//    
//    List l3 = l2;
//    
//    List l4;
//    l4 = l3;
    
    
    // Allocated on heap so I can properly call destructor
    List* first = new List;
    
    first->insertEnd(1);
    first->insertEnd(4);
    first->insertEnd(6);
    first->insertEnd(9);
    
    // Copy all of first into second
    List second(*first);
    
    // Deallocate first, destroying the list;
    // Currently, the deep copy is enabled. Change to the shallow copy version
    // in List.hpp and see what happens!
    delete first;
    
    ListNode* pCur = second.head();
    int iterance = 0;
    
    // Print the entire list.
    while (pCur) {
        cout << "Item " << iterance << ": " << pCur << endl;
        pCur = pCur->next();
    }
    
    
    
    
    
    
    
    /* Here is some interhitance code; at this time, I will not comment on it.
    InheritFromBase iFromB;
    
    // ERROR!
    // x is a protected member of BaseClass, so we cannot access it from a public area.
    // It is only accessible within `InheritFromBase` and `BaseClass`.
    iFromB.x = 20;
    iFromB.publicPrint();
    
    */
    
    return 0;
}
