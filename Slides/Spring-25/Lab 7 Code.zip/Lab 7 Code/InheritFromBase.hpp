//
//  InheritFromBase.hpp
//  Lab 7 Code
//
//  Created by Kyle Parker on 2/25/25.
//

#ifndef InheritFromBase_hpp
#define InheritFromBase_hpp

#include "BaseClass.hpp"

typedef BaseClass Plan;

class InheritFromBase: public BaseClass {
    void test();
};












class DietPlan : public Plan {
    
    DietPlan(int x): Plan(x) {

    }
};

class ExercisePlan : public Plan {
    ExercisePlan(int x): Plan(x) {
    }
};











#endif /* InheritFromBase_hpp */
