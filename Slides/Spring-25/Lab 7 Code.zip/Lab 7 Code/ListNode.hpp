//
//  ListNode.hpp
//  Lab 7 Code
//
//  Created by Kyle Parker on 2/25/25.
//

#ifndef ListNode_hpp
#define ListNode_hpp

class ListNode final {
    int _data;
    ListNode * _next;
    
public:
    ListNode(const int& data) {
        this->_data = data;
        this->_next = nullptr;
    }
    
    ListNode* next() const {
        return _next;
    }
    
    
    int data() const {
        return _data;
    }
    
    void setNext(ListNode*& newNext) {
        this->_next = newNext;
    }
};

#endif /* ListNode_hpp */
