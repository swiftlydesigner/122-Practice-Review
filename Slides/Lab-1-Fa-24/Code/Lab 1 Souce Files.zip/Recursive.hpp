//
//  Recursive.hpp
//  Lab 1
//
//  Created by Kyle Parker on 8/24/24.
//

#ifndef Recursive_hpp
#define Recursive_hpp

#include <stdio.h>

void revStringHelper(char * input, char * end);
char * revString(char * input);

#endif /* Recursive_hpp */
